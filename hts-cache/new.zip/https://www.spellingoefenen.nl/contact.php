<!DOCTYPE html>
<html>
<head>
    
     <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PZGST7WM');</script>
    <!-- End Google Tag Manager -->

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="Revisit-After" content="7 days">
	<meta name="Robots" content="index, follow">

	<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.75, maximum-scale=2">

	<link rel="shortcut icon" type="image/png" href="images/icons/favicon.png">
	<link href="images/icons/icon114.jpg" rel="apple-touch-icon-precomposed" sizes="114x114">
	<link href="images/icons/icon57.jpg" rel="shortcut icon" >
	
	<meta property="og:title" content="SpellingOefenen.nl"> 
	<meta property="og:description" content=""> 
	<meta property="og:image" content="images/icons/poster.jpg"> 

	<meta name="Keywords" content="">
	<meta name="Description" content="">
	
	<title>SpellingOefenen.nl</title>
	
	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Gloria+Hallelujah' rel='stylesheet' type='text/css'>

	<link rel='stylesheet' type='text/css' href='styles/layout.css'>
	<link rel='stylesheet' type='text/css' href='styles/layout_responsive.css'>

	<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js'></script>
	<script type='text/javascript' src='javascript/global.js'></script>
	<script type='text/javascript' src='javascript/jquery.mobile.customized.min.js'></script>
	<script type='text/javascript' src='javascript/jquery.easing.1.3.js'></script> 

</head>
<body>

<!-- *** Networkmenu *** -->
<div id='networkmenu'>

	<div class='networkmenu_item' id='networkmenu_1'><img src='https://afbeeldingen.spellingoefenen.nl/networkmenu/1.png' alt='Spellingoefenen.nl: Spelling oefenen voor groep 3,4,5,6,7 en 8'></div>
	<a href='https://www.taaloefenen.nl' target='_blank' class='networkmenu_item' id='networkmenu_2'><img src='https://afbeeldingen.spellingoefenen.nl/networkmenu/2.png' alt='Taaloefenen.nl: Taal oefenen voor groep 3,4,5,6,7 en 8'></a>
	<a href='https://www.sommenoefenen.nl' target='_blank' class='networkmenu_item' id='networkmenu_3'><img src='https://afbeeldingen.spellingoefenen.nl/networkmenu/3.png' alt='Sommenoefenen.nl: Sommen oefenen voor groep 3,4,5,6,7 en 8'></a>
	<a href='https://www.redactiesommen.nl' target='_blank' class='networkmenu_item' id='networkmenu_4'><img src='https://afbeeldingen.spellingoefenen.nl/networkmenu/4.png' alt='Redactiesommen.nl: Cito rekenen met verhaaltjessommen'></a>

</div>
<!-- *** /Networkmenu *** -->

<div class='header' id='header'>

	<div class='header_div'>

		<a href='/' class='logo'></a>

			<div id='menu' class='menu'>

			<a href='/' class='button'>Home</a>
          		<a href='oefenen.html' class='button'>Oefenen</a>
			<a href='dictee.html' class='button'>Dictee</a>
			<a href='werkwoorden-oefenen.html' class='button_alt'>Werkwoorden</a>
			<a href='spelletjes.html' class='button'>Spelletjes</a>
			<a href='taken.php' class='button_selected'>Klas</a>
			<a href='docenten.php' class='button'>Docenten</a>

		</div>
	
	
	</div>

</div>

<div class='leader'>

	<div class='leader_div'>

		<div class='leader_title'>

		
            
            
		</div>

		
      <div id ="enters"><br><br><br><br><br></div>
	
		
	
	</div>

</div>

<div class='main'>

	<div class='main_div'>
    


		<div class='contactformulier'>
        
	<h1>Contactformulier</h1>
			
 <p>Beste gebruiker!,<br><br>
	 
	 Graag verbeteren wij deze website met uw feedback. We proberen altijd zo snel mogelijk te reageren op uw bericht. Alvast bedankt!


			
			
			</p><br>
				
			<form action='contact_verzenden.php' name='formcreator_contact' method='post' onsubmit="return CheckForm(this, 'Het volgende is nog niet correct:')">

Naam: <span class='ster'>*</span><br>
<input type='text' name='naam' class='form_input' lang='verplicht'>

<br><br>

E-mail: <span class='ster'>*</span><br>
<input type='text' name='email' class='form_input' lang='verplicht[email]'>

<br><br>

Bericht: <span class='ster'>*</span><br>
<textarea name='bericht' class='form_textarea' lang='verplicht'></textarea>

<br><br>

<div class='captcha'>

	<div class='captcha_div'>Typ de 3 cijfers over:</div>
	<div class='captcha_div'><img src='includes/password_img.php?c=5415&color=000000&bgcolor=DDDDDD' alt='Typ deze code over!' width='46' height='25' align='absmiddle'></div>
	<div class='captcha_div'>></div>
	<div class='captcha_div'><input type='hidden' name='c' value='5415'><input type='text' name='userc' class='form_input_captcha' maxlength='3' lang='verplicht[thousand]:Typ de 3 cijfers over!'></div>

</div>

<br><br>

<a href="javascript: if(CheckForm(document.formcreator_contact, 'Het volgende is nog niet correct:')) document.formcreator_contact.submit();" class='button float-shadow'>Verzenden</a>

</form>



</div>
</div>
</div>
<!-- *** /Div popup *** -->



			
            		</div>
				
				</div>
		
			</div>
		



		<br><br><br>


	


<!-- *** Div popup *** -->
<a href='javascript: answerPopupDiv(0);' id='page_screen'></a>

<div name='popup_div' id='popup_div' style='display:none;' onclick='answerPopupDiv(0);'>
<div id='popup_div_td'>
<div id='popup_div_inner' onclick='myEventHandler(event)'>

	<a href='javascript: answerPopupDiv(0);' class='x_button' id='popup_div_inner_x'>x</a>

	<div id='popup_div_content'>

		<div id='popup_div_titel'>titel</div>
		<div id='popup_div_text'>beschrijving</div>
		<div id='popup_div_input'><input type='text' id='popup_input' class='form_input' onKeyPress="return submitenter(this,event)" ></div>

	</div>
		
	<a href='javascript: answerPopupDiv(1);' id='popup_div_button_1' class='button'>button_1</a>
	<a href='javascript: answerPopupDiv(2);' id='popup_div_button_2' class='button_alt'>button_2</a>

</div>
</div>
</div>
<!-- *** /Div popup *** -->



<div class='footer'>
	
	<div class='footer_div'>

		<a href='http://www.gamedesign.nl' title='Game design, webdesign en meer!' target='_blank' class='footer_gamedesign'></a>

		© <span id='jaartal'>2022</span> SpellingOefenen.nl™ &nbsp; | &nbsp; <a href='privacy.html'>Privacy</a> &nbsp; | &nbsp; <a href='https://www.bijdeles.online'>Bijdeles.online</a>  &nbsp; | &nbsp; &nbsp; | &nbsp; <a href='https://www.taaloefenen.nl'>Taal oefenen</a>  &nbsp; | &nbsp; <a href='contact.php'>Contact</a>

	</div>

</div>

</body>
</html>